import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ItemsComponent } from './items/items.component';
import { FormsModule } from '@angular/forms';
import { AccountsModule } from '../accounts/accounts.module';
import { HomeComponent } from './home/home.component';
import { RouterModule } from '@angular/router';
import { OrdersComponent } from './orders/orders.component';




@NgModule({
  declarations: [
    ItemsComponent,
    HomeComponent,
    OrdersComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    AccountsModule,
    RouterModule
  ],
  exports:[ItemsComponent,HomeComponent]
})
export class ItemModule { }
