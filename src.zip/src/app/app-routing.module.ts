import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './accounts/login/login.component';
import { RegisterAdminComponent } from './accounts/register-admin/register-admin.component';
import { RegisterComponent } from './accounts/register/register.component';
import { AdminHomeComponent } from './admin/admin-home/admin-home.component';
import { HomeComponent } from './item/home/home.component';
import { ItemsComponent } from './item/items/items.component';
import { OrdersComponent } from './item/orders/orders.component';

const routes: Routes = [
  {"path":"adminHome/:uname",component:AdminHomeComponent},
  {"path":"login",component:LoginComponent},
  {"path":"items",component:ItemsComponent},
  {"path":"home",component:HomeComponent},
  {"path":"register",component:RegisterComponent},
  {"path":"order/:id",component:OrdersComponent},
  
  {"path":"registerAdmin",component:RegisterAdminComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
