import { Component, OnInit } from '@angular/core';
import { AccountsService } from '../accounts.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
newUname='';
newPwd='';
cust:any;
  constructor(private _ac:AccountsService) { }
addCust(){
 this.cust= {"id":0,"uname":this.newUname,"pwd":this.newPwd,"role":"cust"}
  this._ac.addCust(this.cust);
}
  ngOnInit(): void {
  }

}
