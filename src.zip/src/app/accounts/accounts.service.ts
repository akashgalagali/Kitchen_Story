import { Injectable } from '@angular/core';
import { Users } from './users';

@Injectable({
  providedIn: 'root'
})
export class AccountsService {
loggedIn:boolean=false;
user?:Users;
  users:Users[]=[
  new Users(1001,"akash","akash","admin"),
  new Users(1002,"ashu","kumar","cust"),
  new Users(1003,"kiran","pass","cust"),
  new Users(1004,"krish","pass","admin"),
];
  constructor() { }
  validateUser(uname:string,pwd:string,role:string):boolean{
    
    var user=this.users.filter(x=>x.uname==uname)[0];
    if(user.uname===uname && user.pwd===pwd && user.role===role){
      this.loggedIn= true;
    }
    else{
      this.loggedIn=false;
    }
    return this.loggedIn;
  }
  adminChangePassword(pwd:string,uname:string){
     this.user= this.users.filter(x=>x.uname==uname)[0];
     if(this.user.role==='admin'){
       this.user.pwd=pwd;
     }
  }
  addCust(cust:Users){
    this.users.push(cust); 
  }
}
