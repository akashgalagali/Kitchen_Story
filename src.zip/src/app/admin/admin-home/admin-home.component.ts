import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AccountsService } from 'src/app/accounts/accounts.service';
import { ItemServiceService } from 'src/app/item/item-service.service';
import { Items } from 'src/app/item/items';

@Component({
  selector: 'app-admin-home',
  templateUrl: './admin-home.component.html',
  styleUrls: ['./admin-home.component.css']
})
export class AdminHomeComponent implements OnInit {
newPassword='';
  constructor(private _as:AccountsService,private route: ActivatedRoute,private _itemService:ItemServiceService) { 
    this.getAllItems();
  }
  sub:any;
  uname:string='';
  items?:Items[];
y?:Items[];
name='';
cnt:number=0;
newName:string='';
newPrice:number=0;
newCaleroies:number=0;
newDescription:string='';
newQtyAvailable:number=0;
x:any;
getAllItems(){
  this.items=this._itemService.getAllItems();
}
getItemByName(){
  this.y=this._itemService.getItemByName(this.name);
 
}
addItem(){
  this.x={"id":this.cnt,"itemName":this.newName,"price":this.newPrice,"caleroies":this.newCaleroies,"description":this.newDescription,"qtyAvailable":this.newQtyAvailable};
  this._itemService.addItem(this.x);
}
orderItem(id:any){
  this._itemService.orderItem(id,5);
}

  ngOnInit() {
   
    this.sub = this.route.params.subscribe(params => {
      console.log(params);
      this.uname=params["uname"];
    });
  }

  changePassword(){
    this.sub = this.route.params.subscribe(params => {
      console.log(params);
      this._as.adminChangePassword(this.newPassword,params["uname"]);
    });
 
   
  }

}
